// step1_copy.js
const fs = require('fs');
const path = require('path');

const ROOT_DIR = path.resolve(__dirname, 'dragonbones');

function collectPngFiles(dir, fileList = []) {
    const items = fs.readdirSync(dir, { withFileTypes: true });
    for (const item of items) {
        const fullPath = path.join(dir, item.name);
        if (item.isDirectory()) {
            collectPngFiles(fullPath, fileList);
        } else if (item.isFile() && /\.(png)$/i.test(item.name)) {
            fileList.push(fullPath);
        }
    }
    return fileList;
}

function getTempPath(originalPath) {
    return originalPath.replace(/\.png$/i, '.tmp.png');
}

function main() {
    if (!fs.existsSync(ROOT_DIR)) {
        console.error(`❌ 错误: 目录不存在 "${ROOT_DIR}"`);
        process.exit(1);
    }

    const pngFiles = collectPngFiles(ROOT_DIR);
    if (pngFiles.length === 0) {
        console.log('📭 未在 dragonbones 目录中找到任何 .png 文件');
        return;
    }

    console.log(`✅ 即将复制 ${pngFiles.length} 个 PNG 文件...`);
    for (const file of pngFiles) {
        const tempFile = getTempPath(file);
        try {
            fs.copyFileSync(file, tempFile);
            console.log(`📋 已复制: ${path.basename(file)} → ${path.basename(tempFile)}`);
        } catch (err) {
            console.error(`❌ 复制失败: ${file}`, err.message);
        }
    }
    console.log('\n✅ 第一步完成：所有 PNG 已备份为 .tmp.png');
}

main();