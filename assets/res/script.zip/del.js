// step2_delete.js
const fs = require('fs');
const path = require('path');

const ROOT_DIR = path.resolve(__dirname, 'dragonbones');

function collectPngFiles(dir, fileList = []) {
    const items = fs.readdirSync(dir, { withFileTypes: true });
    for (const item of items) {
        const fullPath = path.join(dir, item.name);
        if (item.isDirectory()) {
            collectPngFiles(fullPath, fileList);
        } else if (item.isFile() && /\.(png)$/i.test(item.name)) {
            fileList.push(fullPath);
        }
    }
    return fileList;
}

function getTempPath(originalPath) {
    return originalPath.replace(/\.png$/i, '.tmp.png');
}

function main() {
    if (!fs.existsSync(ROOT_DIR)) {
        console.error(`❌ 错误: 目录不存在 "${ROOT_DIR}"`);
        process.exit(1);
    }

    const pngFiles = collectPngFiles(ROOT_DIR);
    let deletedCount = 0;

    if (pngFiles.length === 0) {
        console.log('📭 未找到原始 .png 文件（可能已被删除）');
        return;
    }

    console.log(`🗑️  即将删除原始 PNG 文件（仅当 .tmp.png 存在时）...`);
    for (const file of pngFiles) {
        const tempFile = getTempPath(file);
        if (fs.existsSync(tempFile)) {
            try {
                fs.unlinkSync(file);
                console.log(`✅ 已删除: ${path.basename(file)}`);
                deletedCount++;
            } catch (err) {
                console.error(`❌ 删除失败: ${file}`, err.message);
            }
        } else {
            console.warn(`⚠️  跳过: ${path.basename(file)}（缺少临时副本）`);
        }
    }

    console.log(`\n✅ 第二步完成：共删除 ${deletedCount} 个原始文件`);
}

main();