// step3_rename.js
const fs = require('fs');
const path = require('path');

const ROOT_DIR = path.resolve(__dirname, 'dragonbones');

function collectTempFiles(dir, fileList = []) {
    const items = fs.readdirSync(dir, { withFileTypes: true });
    for (const item of items) {
        const fullPath = path.join(dir, item.name);
        if (item.isDirectory()) {
            collectTempFiles(fullPath, fileList);
        } else if (item.isFile() && /\.tmp\.png$/i.test(item.name)) {
            fileList.push(fullPath);
        }
    }
    return fileList;
}

function getOriginalPath(tempPath) {
    return tempPath.replace(/\.tmp\.png$/i, '.png');
}

function main() {
    if (!fs.existsSync(ROOT_DIR)) {
        console.error(`❌ 错误: 目录不存在 "${ROOT_DIR}"`);
        process.exit(1);
    }

    const tempFiles = collectTempFiles(ROOT_DIR);
    if (tempFiles.length === 0) {
        console.log('📭 未找到 .tmp.png 临时文件（可能已完成或未执行第一步）');
        return;
    }

    console.log(`🔁 即将重命名 ${tempFiles.length} 个临时文件...`);
    for (const tempFile of tempFiles) {
        const originalName = getOriginalPath(tempFile);
        try {
            fs.renameSync(tempFile, originalName);
            console.log(`✅ 已重命名: ${path.basename(tempFile)} → ${path.basename(originalName)}`);
        } catch (err) {
            console.error(`❌ 重命名失败: ${tempFile}`, err.message);
        }
    }

    console.log('\n✅ 第三步完成：所有临时文件已恢复为原名');
}

main();